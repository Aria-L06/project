import numpy as np
import torch
from sklearn.preprocessing import scale


def multiomics_data():

    # RNAi_fea
    fea1 = np.genfromtxt("lncrna attribute file1 path", delimiter=' ', dtype=np.dtype(str)) # our_kmer and g_gap (sequence & structure)
    fea2 = np.genfromtxt("lncrna attribute file2 path", delimiter=' ', dtype=np.dtype(str)) # Word2Vec_TF
    fea3 = np.genfromtxt("lncrna attribute file3 path", delimiter=' ', dtype=np.dtype(str)) # Pseudo protein related
    fea4 = np.genfromtxt("lncrna attribute file4 path", delimiter=' ', dtype=np.dtype(str)) # Global transcript sequence descriptors
    fea5 = np.genfromtxt("lncrna attribute file5 path", delimiter=' ', dtype=np.dtype(str)) # GC content properties
    fea6 = np.genfromtxt("lncrna attribute file6 path", delimiter=' ', dtype=np.dtype(str)) # Autocorrelation of dinucleotide & Pseudo dinucleotide composition
    rna_i = np.hstack((fea1, fea2, fea3, fea4, fea5, fea6))
    protein = rna_i[:, 0]
    rna_i_number = len(protein)
    rna_i = np.array(rna_i)
    rna_i = scale(np.array(rna_i[:, 0:], dtype=float))
    rna_i = np.round(rna_i, decimals=4)

    # topological features
    fea7 = np.genfromtxt("lncrna topological file path", delimiter=',', dtype=np.dtype(str))  # our path: ./lncRNA/lncRNA_hin2vec_test.csv
    fea7_subset = np.array(fea7[:,1:])
    fea7_subset = scale(np.array(fea7_subset[:, 0:], dtype=float))
    fea7_subset = np.round(fea7_subset, decimals=4)
    rnai_topo = fea7_subset

    rnai_adj = sim_graph(rna_i, rna_i_number).astype(int)

    # RNAj_fea
    fea1 = np.genfromtxt("mirna attribute file1 path", delimiter=' ', dtype=np.dtype(str))
    fea2 = np.genfromtxt("mirna attribute file2 path", delimiter=' ', dtype=np.dtype(str))
    fea3 = np.genfromtxt("mirna attribute file3 path", delimiter=' ', dtype=np.dtype(str))
    fea4 = np.genfromtxt("mirna attribute file4 path", delimiter=' ', dtype=np.dtype(str))
    fea5 = np.genfromtxt("mirna attribute file5 path", delimiter=' ', dtype=np.dtype(str))
    fea6 = np.genfromtxt("mirna attribute file6 path", delimiter=' ', dtype=np.dtype(str))
    rna_j = np.hstack((fea1, fea2, fea3, fea4, fea5, fea6))
    drug = rna_j[:, 0]
    rna_j_number = len(drug)
    rna_j = np.array(rna_j)
    rna_j = scale(np.array(rna_j[:, 0:], dtype=float))
    rna_j = np.round(rna_j, decimals=4)

    # topological features
    fea7 = np.genfromtxt("mirna topological file path", delimiter=',', dtype=np.dtype(str))
    fea7_subset = np.array(fea7[:, 1:])
    fea7_subset = scale(np.array(fea7_subset[:, 0:], dtype=float))
    fea7_subset = np.round(fea7_subset, decimals=4)
    rnaj_topo = fea7_subset
    rnaj_adj = sim_graph(rna_j, rna_j_number).astype(int)

    # label
    labellist = []
    with open('label_remain file path', 'r') as file:
        lines = file.readlines()
    for line in lines:
        line = line.strip()
        elements = line.split(" ")
        processed_elements = [int(elements[0]), int(elements[1]), int(elements[2])]
        labellist.append(processed_elements)
    labellist = torch.Tensor(labellist)
    print("RNA-RNA lable:", labellist.shape)

    # label_test
    labellist_test = []
    with open('label_test file path', 'r') as file:
        lines = file.readlines()
    for line in lines:
        line = line.strip()
        elements = line.split(" ")
        processed_elements = [int(elements[0]), int(elements[1]), int(elements[2])]
        labellist_test.append(processed_elements)
    labellist_test = torch.Tensor(labellist_test)
    print("RNA-RNA lable:", labellist_test.shape)


    rnai_fea, rnaj_fea = torch.FloatTensor(rna_i),  torch.FloatTensor(rna_j)
    rnai_adj, rnaj_adj = torch.FloatTensor(rnai_adj), torch.FloatTensor(rnaj_adj)
    rnai_topo,rnaj_topo = torch.tensor(rnai_topo, dtype=torch.float), torch.tensor(rnaj_topo, dtype=torch.float)
    return rnai_fea, rnai_adj ,rnaj_fea, rnaj_adj, labellist, labellist_test, rnai_topo, rnaj_topo




def sim_graph(omics_data, rna_number):
    sim_matrix = np.zeros((rna_number, rna_number), dtype=float)
    adj_matrix = np.zeros((rna_number, rna_number), dtype=float)

    # calculate the similarity matrix）
    for i in range(rna_number):
        for j in range(i + 1):
            sim_matrix[i, j] = np.dot(omics_data[i], omics_data[j]) / (
                    np.linalg.norm(omics_data[i]) * np.linalg.norm(omics_data[j]))
            sim_matrix[j, i] = sim_matrix[i, j]

    for i in range(rna_number):
        topindex = np.argsort(sim_matrix[i])[-10:]
        for j in topindex:
            adj_matrix[i, j] = sim_matrix[i, j]

    node_degrees = np.sum(adj_matrix, axis=1)
    min_val = np.min(node_degrees)
    max_val = np.max(node_degrees)
    if max_val > min_val:
        node_degrees = (node_degrees - min_val) / (max_val - min_val)
    else:
        node_degrees = np.zeros_like(node_degrees)

    # the edge importance score
    importance_matrix = np.zeros((rna_number, rna_number), dtype=float)
    for i in range(rna_number):
        for j in range(rna_number):
            if adj_matrix[i, j] > 0:
                importance_matrix[i, j] = (node_degrees[i] + node_degrees[j]) / 2

    return importance_matrix

