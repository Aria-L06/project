from layers import *


class MultiDeep(nn.Module):
    def __init__(self, nlnc, nmi, nlncfeat, nmifeat, nhid, alpha, ntopo):
        """Dense version of GNN."""
        super(MultiDeep, self).__init__()

        # lncRNA
        self.lnc_GCN1 = GraphConvolutionLayer(nlncfeat, ntopo)
        self.lnc_GCN2 = GraphConvolutionLayer(ntopo, ntopo)
        self.lnc_gat1 = GraphAttentionLayer(nlncfeat, ntopo, alpha=alpha, concat=True)
        self.lnc_gat2 = GraphAttentionLayer(ntopo, ntopo, alpha=alpha, concat=True)

        # attention layer
        self.lnc_att = selfattention(ntopo, nhid, ntopo)
        self.prolayer_att = nn.Linear(ntopo, ntopo, bias=False)

        self.lnc_prolayer1 = nn.Linear(ntopo, ntopo, bias=False)
        self.lnc_LNlayer1 = nn.LayerNorm(ntopo)
        self.dropout = nn.Dropout(p=0.6)


        # miRNA
        self.mi_GCN1 = GraphConvolutionLayer(nmifeat, ntopo)
        self.mi_GCN2 = GraphConvolutionLayer(ntopo, ntopo)
        self.mi_gat1 = GraphAttentionLayer(nmifeat, ntopo, alpha=alpha, concat=True)
        self.mi_gat2 = GraphAttentionLayer(ntopo, ntopo, alpha=alpha, concat=True)

        # attention layer
        self.mi_att = selfattention(ntopo, nhid, ntopo)

        self.mi_prolayer1 = nn.Linear(ntopo, ntopo, bias=False)
        self.mi_LNlayer1 = nn.LayerNorm(ntopo)

        # fully connected layer
        self.FClayer1 = nn.Linear(ntopo, ntopo)
        self.FClayer2 = nn.Linear(ntopo, 32)
        self.FClayer3 = nn.Linear(32, 1)

        self.output = nn.Sigmoid()

    def forward(self, lnc_features, lnc_adj, mi_features, mi_adj, idx_lnc_mi, device, lnc_topo, mi_topo):

        # GCN with inter-layer attention mechanism
        lnc_c1 = self.lnc_GCN1(lnc_features, lnc_adj)
        lnc_c1 = self.lnc_LNlayer1(lnc_c1)
        lnc_c2 = self.lnc_GCN2(lnc_c1, lnc_adj)
        lnc_c2 = self.lnc_LNlayer1(lnc_c2)
        lnc_c3 = self.lnc_GCN2(lnc_c2, lnc_adj)
        lnc_c3 = self.lnc_LNlayer1(lnc_c3)

        lnc_c = torch.cat((lnc_c1.unsqueeze(1), lnc_c2.unsqueeze(1), lnc_c3.unsqueeze(1)), dim=1)
        lnc_c = self.lnc_att(lnc_c)
        lnc_c = self.dropout(lnc_c)
        lnc_c = self.lnc_prolayer1(lnc_c)
        lnc_c = self.lnc_LNlayer1(lnc_c)

        # GAT with node-level attention mechanism
        lnc_g = self.lnc_gat1(lnc_features, lnc_adj)
        lnc_g= self.dropout(lnc_g)
        lnc_g = self.prolayer_att(lnc_g)

        lnc_g = self.lnc_gat2(lnc_g, lnc_adj)
        lnc_g = self.dropout(lnc_g)
        lnc_g = self.prolayer_att(lnc_g)

        # feature fusion with feature_level attention mechanism
        lncx = torch.cat((lnc_c.unsqueeze(1), lnc_g.unsqueeze(1)), dim=1)
        lnc_c = self.lnc_att(lncx)
        lncx = torch.cat((lnc_c.unsqueeze(1), lnc_topo.unsqueeze(1)), dim=1)
        lnc_c = self.lnc_att(lncx)
        lnc_c = self.dropout(lnc_c)
        lnc_c = self.lnc_prolayer1(lnc_c)
        lnc_x = self.lnc_LNlayer1(lnc_c)


        # miRNA
        # GCN with inter-layer attention mechanism
        mi_1 = self.mi_GCN1(mi_features, mi_adj)
        mi_1 = self.mi_LNlayer1(mi_1)
        mi_2 = self.mi_GCN2(mi_1, mi_adj)
        mi_2 = self.mi_LNlayer1(mi_2)
        mi_3 = self.mi_GCN2(mi_2, mi_adj)
        mi_3 = self.mi_LNlayer1(mi_3)

        mi_c = torch.cat((mi_1.unsqueeze(1), mi_2.unsqueeze(1), mi_3.unsqueeze(1)), dim=1)
        mi_c = self.mi_att(mi_c)
        mi_c = self.dropout(mi_c)
        mi_c = self.mi_prolayer1(mi_c)
        mi_c = self.mi_LNlayer1(mi_c)

        # GAT with node-level attention mechanism
        mi_g = self.mi_gat1(mi_features, mi_adj)
        mi_g = self.dropout(mi_g)
        mi_g = self.prolayer_att(mi_g)

        mi_g = self.mi_gat2(mi_g, mi_adj)
        mi_g = self.dropout(mi_g)
        mi_g = self.prolayer_att(mi_g)

        # feature fusion with feature_level attention mechanism
        mix = torch.cat((mi_c.unsqueeze(1), mi_g.unsqueeze(1)), dim=1)
        mi_c = self.mi_att(mix)
        mix = torch.cat((mi_c.unsqueeze(1), mi_topo.unsqueeze(1)), dim=1)
        mi_c = self.mi_att(mix)
        mi_c = self.dropout(mi_c)
        mi_c = self.mi_prolayer1(mi_c)
        mi_x = self.mi_LNlayer1(mi_c)


        # use Hadamard to splice
        lnc_features = lnc_x[idx_lnc_mi[:, 0]]
        mi_features = mi_x[idx_lnc_mi[:, 1]]
        lnc_mi_x = lnc_features * mi_features
        # lnc_mi_x = torch.cat((lnc_x[idx_lnc_mi[:, 0]], mi_x[idx_lnc_mi[:, 1]]), dim=1)


        lnc_mi_x = lnc_mi_x.to(device)
        lnc_mi_x = self.FClayer1(lnc_mi_x)
        lnc_mi_x = F.relu(lnc_mi_x)
        lnc_mi_x = self.FClayer2(lnc_mi_x)
        lnc_mi_x = F.relu(lnc_mi_x)
        lnc_mi_x = self.FClayer3(lnc_mi_x)
        lnc_mi_x = lnc_mi_x.squeeze(-1)
        return lnc_mi_x
