# Nucleotide related

import sys
import os
ac_path = os.path.join(os.path.dirname(__file__), 'repDNA')
sys.path.append(ac_path)
import repDNA.ac as RNA_ac
import repDNA.psenac as RNA_psenac
import pandas as pd


def switch_meth(fun, textPath):
    fun = '17'
    if fun == '17':
        # print('This step is wrong')
        dac = RNA_ac.rna_dac(textPath,2)
        # print('dac is wrong')        
        dcc = RNA_ac.rna_dcc(textPath,2)
        # print('dcc is wrong')
        psenac = RNA_psenac.rna_pc_psednc(textPath)
        # print('psenac is wrong')
        SCPseDNC = RNA_psenac.rna_SCPseDNC(textPath)


        T1 = pd.concat([dac, dcc], axis=1, join='inner')
        T1 = pd.concat([T1, psenac], axis=1, join='inner')
        T1 = pd.concat([T1, SCPseDNC], axis=1, join='inner')

        return T1
    else:
        return None

if __name__ == '__main__':
    textPath = "lncrna.fasta"
    result = switch_meth(17,textPath)
    result_strings = result.apply(lambda row: ' '.join(row.astype(str)), axis=1)
    result_strings.to_csv('Nucleotide_lnc.csv', sep='\t', index=False, header=False)

