import numpy as np
import re
import math
from sklearn import ensemble
from gensim.models import Word2Vec
from collections import defaultdict
from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
import pandas as pd
from GCcounts import GCconder
from CTDcode import CTDcoder
from proparcoder import ProtPar
from sklearn.feature_extraction.text import TfidfVectorizer


# np.random.seed(1337) # random seed
#
separator, Sequencekmertotal, SequenceGgaptotal, Structurekmertotal, StructureGgaptotal = ' ', 3, 3, 3, 3

def SequencekmerExtract(sequence, totalkmer):
    sequence = sequence.replace('U', 'T')
    character = 'ATCG'
    sequencekmer = ''
    for k in range(totalkmer):
        kk = k + 1
        sk = len(sequence) - kk + 1
        wk = 1 / (4 ** (totalkmer - kk))
        # 1-mer
        if kk == 1:
            for char11 in character:
                s1 = char11
                f1 = wk * sequence.count(s1) / sk
                string1 = str(f1) + separator
                sequencekmer = sequencekmer + string1
        # 2-mer
        if kk == 2:
            for char21 in character:
                for char22 in character:
                    s2 = char21 + char22
                    numkmer2 = 0
                    for lkmer2 in range(len(sequence) - kk + 1):
                        if sequence[lkmer2] == s2[0] and sequence[lkmer2 + 1] == s2[1]:
                            numkmer2 = numkmer2 + 1
                    f2 = wk * numkmer2 / sk
                    string2 = str(f2) + separator
                    sequencekmer = sequencekmer + string2
        # 3-mer
        if kk == 3:
            for char31 in character:
                for char32 in character:
                    for char33 in character:
                        s3 = char31 + char32 + char33
                        numkmer3 = 0
                        for lkmer3 in range(len(sequence) - kk + 1):
                            if sequence[lkmer3] == s3[0] and sequence[lkmer3 + 1] == s3[1] and sequence[lkmer3 + 2] == s3[2]:
                                numkmer3 = numkmer3 + 1
                        f3 = wk * numkmer3 / sk
                        string3 = str(f3) + separator
                        sequencekmer = sequencekmer + string3
    return sequencekmer

def SequenceGgapExtract(sequence, totalGgap):
    sequence = sequence.replace('U', 'T')
    character = 'ATCG'
    sequenceGgap = ''
    for k in range(totalGgap):
        kk = k + 1
        sk = len(sequence) - kk + 1
        wk = 1 / (4 ** (totalGgap - kk))
        if kk == 1:
            for char11 in character:
                for char12 in character:
                    num1 = 0
                    for l1 in range(len(sequence) - kk - 1):
                        if sequence[l1] == char11 and sequence[l1 + kk + 1] == char12:
                            num1 = num1 + 1
                    f1 = wk * num1 / sk
                    string1 = str(f1) + separator
                    sequenceGgap = sequenceGgap + string1
        if kk == 2:
            for char21 in character:
                for char22 in character:
                    num2 = 0
                    for l2 in range(len(sequence) - kk - 3):
                        if sequence[l2] == char21 and sequence[l2 + kk + 1] == char22:
                            num2 = num2 + 1
                    f2 = wk * num2 / sk
                    string2 = str(f2) + separator
                    sequenceGgap = sequenceGgap + string2
        if kk == 3:
            for char31 in character:
                for char32 in character:
                    num3 = 0
                    for l3 in range(len(sequence) - kk - 3):
                        if sequence[l3] == char31 and sequence[l3 + kk + 1] == char32:
                            num3 = num3 + 1
                    f3 = wk * num3 / sk
                    string3 = str(f3) + separator
                    sequenceGgap = sequenceGgap + string3
    return sequenceGgap

def StructurekmerExtract(structure, totalkmer):
    character = ').'
    structurekmer = '' # 特征

    sp = structure.split()
    ssf = sp[0]
    ssf = ssf.replace('(', ')')
    for k in range(totalkmer):
        kk = k + 1
        sk = len(ssf) - kk + 1
        wk = 1 / (2 ** (totalkmer - kk))
        # 1-mer
        if kk == 1:
            for char11 in character:
                s1 = char11
                f1 = wk * ssf.count(s1) / sk
                string1 = str(f1) + separator
                structurekmer = structurekmer + string1
        # 2-mer
        if kk == 2:
            for char21 in character:
                for char22 in character:
                    s2 = char21 + char22
                    numkmer2 = 0
                    for lkmer2 in range(len(ssf) - kk + 1):
                        if ssf[lkmer2] == s2[0] and ssf[lkmer2 + 1] == s2[1]:
                            numkmer2 = numkmer2 + 1
                    f2 = wk * numkmer2 / sk
                    string2 = str(f2) + separator
                    structurekmer = structurekmer + string2
        # 3-mer
        if kk == 3:
            for char31 in character:
                for char32 in character:
                    for char33 in character:
                        s3 = char31 + char32 + char33
                        numkmer3 = 0
                        for lkmer3 in range(len(ssf) - kk + 1):
                            if ssf[lkmer3] == s3[0] and ssf[lkmer3 + 1] == s3[1] and ssf[lkmer3 + 2] == s3[2]:
                                numkmer3 = numkmer3 + 1
                        f3 = wk * numkmer3 / sk
                        string3 = str(f3) + separator
                        structurekmer = structurekmer + string3
    return structurekmer

def StructureGgapExtract(structure, totalGgap):
    character = ').'
    structureGgap = ''
    sp = structure.split()
    ssf = sp[0]
    ssf = ssf.replace('(', ')')
    for k in range(totalGgap):
        kk = k + 1
        sk = len(ssf) - kk + 1
        wk = 1 / (2 ** (totalGgap - kk))
        if kk == 1:
            for char11 in character:
                for char12 in character:
                    for char13 in character:
                        for char14 in character:
                            num1 = 0
                            for l1 in range(len(ssf) - kk - 3):
                                if ssf[l1] == char11 and ssf[l1 + 1] == char12 and ssf[l1 + kk + 2] == char13 and ssf[l1 + kk + 3] == char14:
                                    num1 = num1 + 1
                            f1 = wk * num1 / sk
                            string1 = str(f1) + separator
                            structureGgap = structureGgap + string1
        if kk == 2:
            for char21 in character:
                for char22 in character:
                    for char23 in character:
                        for char24 in character:
                            num2 = 0
                            for l2 in range(len(ssf) - kk - 3):
                                if ssf[l2] == char21 and ssf[l2 + 1] == char22 and ssf[l2 + kk + 2] == char23 and ssf[l2 + kk + 3] == char24:
                                    num2 = num2 + 1
                            f2 = wk * num2 / sk
                            string2 = str(f2) + separator
                            structureGgap = structureGgap + string2
        if kk == 3:
            for char31 in character:
                for char32 in character:
                    for char33 in character:
                        for char34 in character:
                            num3 = 0
                            for l3 in range(len(ssf) - kk - 3):
                                if ssf[l3] == char31 and ssf[l3 + 1] == char32 and ssf[l3 + kk + 2] == char33 and ssf[l3 + kk + 3] == char34:
                                    num3 = num3 + 1
                            f3 = wk * num3 / sk
                            string3 = str(f3) + separator
                            structureGgap = structureGgap + string3
    return structureGgap

def ArithmeticLevel(feature1, feature2):
    fpair = ''
    if feature1 != '' and feature2 != '':
        f1, f2 = feature1.strip().split(' '), feature2.strip().split(' ')
        for i in range(len(f1)):
            a = float(f1[i])
            b = float(f2[i])
            c = 50 * (a + b) / 2
            fpair += str(c) + separator
    return fpair

def get_kmers(sequence, k):
    kmers = [sequence[i:i + k] for i in range(len(sequence) - k + 1)]
    return kmers


def get_sequence_vector(sequence, model, k, tfidf_weights):
    kmers = get_kmers(sequence, k)
    vector_size = model.vector_size
    sequence_vector = np.zeros(vector_size)
    count = 0
    for kmer in kmers:
        if kmer in model.wv:
            tfidf_weight = tfidf_weights.get(kmer, 1.0)
            sequence_vector += model.wv[kmer] * tfidf_weight
            count += 1
    if count > 0:
        sequence_vector /= count
    return sequence_vector


def kmer_word2vec(seq, k):
    seq = seq[:-(len(seq) % 3)] if len(seq) % 3 != 0 else seq
    kmers = get_kmers(seq, k)
    sentences = [" ".join(kmers)]

    # caculate TF-IDF weights
    tfidf_vectorizer = TfidfVectorizer()
    tfidf_vectorizer.fit(sentences)
    tfidf_features = tfidf_vectorizer.transform(sentences)

    # create a word to TF-IDF weight mapping
    feature_names = tfidf_vectorizer.get_feature_names_out()
    tfidf_weights = {feature_names[i]: tfidf_features[0, i] for i in range(len(feature_names))}

    model = Word2Vec(vector_size=32, window=5, min_count=1, sg=1, negative=5)
    model.build_vocab([kmers])
    model.train([kmers], total_examples=model.corpus_count, epochs=50)

    # feature representation of RNA sequence with TF-IDF weights
    sequence_vector = get_sequence_vector(seq, model, k, tfidf_weights)

    sequence_vector_str = ' '.join(map(str, sequence_vector))
    return sequence_vector_str


pathi='../data/lncRNA_data.csv'
list_tv_set = open(pathi, 'r').readlines()
CTD = []
Protpar = []
GC = []
w2v = []
Feature = []
for line in list_tv_set:
    RNAiname, RNAisequence, RNAistructure = line.strip().split(',')
    # RNAi sequence k-mer
    SequenceRNAikmer = SequencekmerExtract(RNAisequence, Sequencekmertotal)
    # RNAi sequence g-gap
    SequenceRNAiGgap = SequenceGgapExtract(RNAisequence, SequenceGgaptotal)
    # RNAi structure k-mer
    StructureRNAikmer = StructurekmerExtract(RNAistructure, Structurekmertotal)
    # RNAi structure g-gap
    StructureRNAiGgap = StructureGgapExtract(RNAistructure, StructureGgaptotal)
    featurei = SequenceRNAikmer + SequenceRNAiGgap + StructureRNAikmer + StructureRNAiGgap
    Feature.append(f"{featurei}")
    # k_mer + Word2Vec_TF
    k_word2vec = kmer_word2vec(RNAisequence, 3)
    w2v.append(f"{k_word2vec}")
    # GC_feature
    gc_calculator = GCconder(sequence=RNAisequence)
    gc = gc_calculator.get_gc()
    gc = ' '.join(map(str, gc))
    GC.append(gc)
    # CTD_feature
    ctd_calculator = CTDcoder(sequence=RNAisequence)
    ctd = ctd_calculator.CTD()
    ctd = ' '.join(map(str, ctd))
    CTD.append(f"{ctd}")
    # Pseudo protein
    protpar = ProtPar(RNAisequence)
    pro_fea = protpar.get_features()
    Protpar.append(pro_fea)

scaler = MinMaxScaler()
Protpar= scaler.fit_transform(Protpar)
pro_str = [' '.join(map(str, features)) for features in Protpar]


with open ('../data/lncRNA/Word2Vec_TF.csv','w') as file:
    for fea in w2v:
        file.write(fea+'\n')
with open ('../data/lncRNA/GC_related.csv','w') as file1:
    for gc in GC:
        file1.write(gc+'\n')
with open ('../data/lncRNA/CTD_sequence.csv','w') as file2:
    for gc in CTD:
        file2.write(gc+'\n')
with open ('../data/lncRNA/Protpar.csv','w') as file3:
    for pro in pro_str:
        file3.write(pro+'\n')
with open ('../data/lncRNA/Feature_i.csv','w') as file4:
    for pro in Feature:
        file4.write(pro+'\n')



pathj='data/miRNA_data.csv'
tv_set = open(pathj, 'r').readlines()
Feature_j=[]
CTD_j = []
Protpar_j = []
GC_j = []
w2v_j = []
for line in tv_set:
    RNAiname, RNAisequence, RNAistructure = line.strip().split(',')
    # RNAi sequence k-mer
    SequenceRNAikmer = SequencekmerExtract(RNAisequence, Sequencekmertotal)
    # RNAi sequence g-gap
    SequenceRNAiGgap = SequenceGgapExtract(RNAisequence, SequenceGgaptotal)
    # RNAi structure k-mer
    StructureRNAikmer = StructurekmerExtract(RNAistructure, Structurekmertotal)
    # RNAi structure g-gap
    StructureRNAiGgap = StructureGgapExtract(RNAistructure, StructureGgaptotal)
    seq = SequenceRNAikmer + SequenceRNAiGgap
    strc = StructureRNAikmer + StructureRNAiGgap
    # k_mer + Word2Vec_TF
    k_word2vec = kmer_word2vec(RNAisequence, 3)
    w2v_j.append(f"{k_word2vec}")
    # GC_feature
    gc_calculator = GCconder(sequence=RNAisequence)
    gc = gc_calculator.get_gc()
    gc = ' '.join(map(str, gc))
    GC_j.append(gc)
    # CTD_feature
    ctd_calculator = CTDcoder(sequence=RNAisequence)
    ctd = ctd_calculator.CTD()
    ctd = ' '.join(map(str, ctd))
    CTD_j.append(f"{ctd}")
    # Pseudo protein
    protpar = ProtPar(RNAisequence)
    pro_fea = protpar.get_features()
    Protpar_j.append(pro_fea)

scaler = MinMaxScaler()
Protpar_j= scaler.fit_transform(Protpar_j)
pro_str_j = [' '.join(map(str, features)) for features in Protpar_j]


with open ('data/miRNA/Word2Vec_TF.csv','w') as file:
    for fea in w2v_j:
        file.write(fea+'\n')
with open ('data/miRNA/GC_related.csv','w') as file1:
    for gc in GC_j:
        file1.write(gc+'\n')
with open ('data/miRNA/CTD_sequence.csv','w') as file2:
    for gc in CTD_j:
        file2.write(gc+'\n')
with open ('data/miRNA/Protpar.csv','w') as file3:
    for pro in pro_str_j:
        file3.write(pro+'\n')
with open ('data/miRNA/Feature_j.csv','w') as file4:
    for pro in Feature_j:
        file4.write(pro+'\n')
