import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

#GAT
class GraphAttentionLayer(nn.Module):
    """
    Simple GAT layer, similar to https://arxiv.org/abs/1710.10903. This part of code refers to the implementation of https://github.com/Diego999/pyGAT.git

    """
    def __init__(self, in_features, out_features, alpha, concat=True):
        super(GraphAttentionLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha
        self.concat = concat

        self.W = nn.Parameter(torch.empty(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)
        self.a = nn.Parameter(torch.empty(size=(2 * out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)
        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, h, adj):
        Wh = torch.mm(h, self.W)  # h.shape: (N, in_features), Wh.shape: (N, out_features)
        a_input = self._prepare_attentional_mechanism_input(Wh)
        e = self.leakyrelu(torch.matmul(a_input, self.a).squeeze(2))  # （N，N）

        zero_vec = -9e15 * torch.ones_like(e)  # 创建一个与 e 形状相同的负无穷大矩阵
        attention = torch.where(adj > 0, e, zero_vec)  # 只保留邻接矩阵中有连接的注意力系数，其余位置填充负无穷大。
        attention = F.softmax(attention, dim=1)   # 归一化  (N，N）

        h_prime = torch.matmul(attention, Wh)
        return F.relu(h_prime)

    def _prepare_attentional_mechanism_input(self, Wh):
        N = Wh.size()[0]  # number of nodes

        # Below, two matrices are created that contain embeddings in their rows in different orders.
        # (e stands for embedding)
        # These are the rows of the first matrix (Wh_repeated_in_chunks):
        # e1, e1, ..., e1,            e2, e2, ..., e2,            ..., eN, eN, ..., eN
        # '-------------' -> N times  '-------------' -> N times       '-------------' -> N times
        #
        # These are the rows of the second matrix (Wh_repeated_alternating):
        # e1, e2, ..., eN, e1, e2, ..., eN, ..., e1, e2, ..., eN
        # '----------------------------------------------------' -> N times
        #

        Wh_repeated_in_chunks = Wh.repeat_interleave(N, dim=0)
        Wh_repeated_alternating = Wh.repeat(N, 1)


        all_combinations_matrix = torch.cat([Wh_repeated_in_chunks, Wh_repeated_alternating], dim=1)

        return all_combinations_matrix.view(N, N, 2 * self.out_features)


    def __repr__(self):
        return self.__class__.__name__ + ' (' + str(self.in_features) + ' -> ' + str(self.out_features) + ')'


class selfattention(nn.Module):
    def __init__(self, feature_dim, d_k, d_v):
        super().__init__()
        self.d_k = d_k
        self.d_v = d_v
        self.query = nn.Linear(feature_dim, d_k)  # the dimension of each feature is feature_dim
        self.key = nn.Linear(feature_dim, d_k)
        self.value = nn.Linear(feature_dim, d_v)

    def forward(self, x):
        # Shape of x is (batch_size, num_layers, feature_dim)
        q = self.query(x)  # (batch_size, num_layers d_k)
        k = self.key(x)  # (batch_size, num_layers, d_k)
        v = self.value(x)  # (batch_size, num_layers, d_v)

        # Calculate the attention matrix (batch_size, num_layers, num_layers)
        att = torch.matmul(q, k.transpose(1, 2)) / np.sqrt(self.d_k)
        att = torch.softmax(att, dim=-1)

        # calculate the weighted value
        weighted_value = torch.matmul(att, v)  # (batch_size, num_layers, d_v)
        # sum or average the weighted values of the features
        output = weighted_value.sum(dim=1)  # 或者可以使用mean(dim=1)来取平均

        return output  # (batch_size, d_v)


#GCN
class GraphConvolutionLayer(nn.Module):
    def __init__(self, in_features, out_features, nheads=4):
        super(GraphConvolutionLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.nheads = nheads

        self.W = nn.Parameter(torch.empty(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)

    def forward(self, h, adj):
        Wh = torch.mm(h, self.W)  # h.shape: (N, in_features), Wh.shape: (N, out_features)
        output = torch.matmul(adj, Wh)
        return F.relu(output)

